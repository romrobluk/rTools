import asyncio
import discord
from discord import Webhook
import aiohttp
import rutils.wspammer
import rutils.wnitro
import os
import time
import random

def main():
        os.system('cls')
        print("""
      
       $$$$$$$$\                  $$\           
       \__$$  __|                 $$ |          
 $$$$$$\  $$ | $$$$$$\   $$$$$$\  $$ | $$$$$$$\ 
$$  __$$\ $$ |$$  __$$\ $$  __$$\ $$ |$$  _____|
$$ |  \__|$$ |$$ /  $$ |$$ /  $$ |$$ |\$$$$$$\  
$$ |      $$ |$$ |  $$ |$$ |  $$ |$$ | \____$$\ 
$$ |      $$ |\$$$$$$  |\$$$$$$  |$$ |$$$$$$$  |
\__|      \__| \______/  \______/ \__|\_______/ 
                                                

        [1] - Discord Webhook Spammer   

        [2] - Discord Webhook Nitro                                                                               
                                                                                  
""")
        ans = input()
        ans = int(ans)
        if ans == 1:
                rutils.wspammer.wspammer()
                main()
        elif ans == 2:
                rutils.wnitro.wnitro()
                main()
        else:
                main()
main()